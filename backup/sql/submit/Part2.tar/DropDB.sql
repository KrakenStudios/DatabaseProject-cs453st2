##
#Chris Ward
#Matt Stender
#Diego Gonzalez
#Drops our database
##
DROP DATABASE IF EXISTS cs453db2;
